//
//  StackOverflowResponse.swift
//  SafeHealthChallenge
//
//  Created by Rickie on 3/10/22.
//

import Foundation

struct StackOverflowResponse: Decodable {
    let items: [StackOverflowItem]
}


